#!/bin/bash

for file in AliSQL-*
do
    newfilename=${file/AliSQL/alisql}
    mv ${file} ${newfilename}
done
