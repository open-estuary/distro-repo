This folder contains an implementation of a simple compiler that
translates a programs written in a subset of P4 into C that can in
turn be compiled into EBPF using the IOVisor bcc compiler.

