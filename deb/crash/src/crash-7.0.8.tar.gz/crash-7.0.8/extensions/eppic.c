/*
   Place holder for proper working of the extension Makefile.
   Eppic crash application file is in eppic/applications/crash/eppic.c
*/
