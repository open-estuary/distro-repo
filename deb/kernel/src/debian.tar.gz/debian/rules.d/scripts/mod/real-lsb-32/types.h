#include "../types.h"
typedef __u32 kernel_ulong_t;
#define BITS_PER_LONG 32
