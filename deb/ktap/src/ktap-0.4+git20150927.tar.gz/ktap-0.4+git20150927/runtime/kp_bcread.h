#ifndef __KTAP_BCREAD_H__
#define __KTAP_BCREAD_H__

ktap_proto_t *kp_bcread(ktap_state_t *ks, unsigned char *buff, int len);

#endif /* __KTAP_BCREAD_H__ */
