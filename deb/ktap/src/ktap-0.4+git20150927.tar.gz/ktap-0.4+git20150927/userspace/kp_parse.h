
ktap_proto_t *kp_parse(LexState *ls);
ktap_str_t *kp_parse_keepstr(LexState *ls, const char *str, size_t l);

