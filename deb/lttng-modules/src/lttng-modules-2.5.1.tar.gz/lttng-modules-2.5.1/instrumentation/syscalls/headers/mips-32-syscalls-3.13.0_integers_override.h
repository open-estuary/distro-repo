/*
 * this is a place-holder for MIPS integer syscall definition override.
 */
