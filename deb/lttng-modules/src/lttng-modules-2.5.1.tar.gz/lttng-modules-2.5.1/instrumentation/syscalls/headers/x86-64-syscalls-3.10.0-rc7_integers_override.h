/*
 * this is a place-holder for x86_64 integer syscall definition override.
 */
