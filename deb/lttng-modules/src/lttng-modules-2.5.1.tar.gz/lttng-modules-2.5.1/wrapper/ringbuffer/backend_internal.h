#include "../../wrapper/inline_memcpy.h"
#include "../../lib/ringbuffer/backend_internal.h"
