#include "../../lib/ringbuffer/vatomic.h"
