#ifndef _STAPDYN_ADDR_MAP_C_
#define _STAPDYN_ADDR_MAP_C_ 1

static int
lookup_bad_addr(unsigned long addr, size_t size)
{
	return 0;
}

#endif /* _STAPDYN_ADDR_MAP_C_ */
