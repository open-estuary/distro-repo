#include <linux/hrtimer.h>

int x = HRTIMER_REL;  /* as opposed to HRTIMER_MODE_REL */
