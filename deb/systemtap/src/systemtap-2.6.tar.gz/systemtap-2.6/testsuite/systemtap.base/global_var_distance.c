static int value;

void setdistance(int v) { value = v; }
int getdistance() { return value; }
