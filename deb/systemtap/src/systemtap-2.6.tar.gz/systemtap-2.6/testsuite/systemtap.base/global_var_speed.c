static int value;

void setspeed(int v) { value = v; }
int getspeed() { return value; }
