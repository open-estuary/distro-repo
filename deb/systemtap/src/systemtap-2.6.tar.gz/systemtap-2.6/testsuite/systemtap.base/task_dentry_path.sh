#!/bin/sh
cd /tmp
BASE="$(cd $(dirname ".")/../..; pwd -P)"
echo $BASE
