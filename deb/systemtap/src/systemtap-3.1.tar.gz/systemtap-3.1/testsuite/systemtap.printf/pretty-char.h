struct pretty_chars { char a, b, c, d, e; };
