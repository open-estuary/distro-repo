def MyFunction():
    print("MyFunction called")

def second_func():
    print("second_func called")

if __name__ == "__main__":
    MyFunction()
