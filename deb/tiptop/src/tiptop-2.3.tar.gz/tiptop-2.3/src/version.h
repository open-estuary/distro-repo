/*
 * This file is part of tiptop.
 *
 * Author: Erven ROHOU
 * Copyright (c) 2011, 2012 Inria
 *
 * License: GNU General Public License version 2.
 *
 */

#ifndef _VERSION_H
#define _VERSION_H

void print_version(void);
void print_legal(void);

#endif
