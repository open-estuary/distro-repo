#!/bin/bash

source scl_source enable php54
