#!/bin/bash

source scl_source enable rh-postgresql94
