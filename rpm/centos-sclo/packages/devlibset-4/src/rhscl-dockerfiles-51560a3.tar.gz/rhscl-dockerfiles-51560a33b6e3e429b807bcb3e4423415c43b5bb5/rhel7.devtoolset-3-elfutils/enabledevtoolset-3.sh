#!/bin/bash

source scl_source enable devtoolset-3
