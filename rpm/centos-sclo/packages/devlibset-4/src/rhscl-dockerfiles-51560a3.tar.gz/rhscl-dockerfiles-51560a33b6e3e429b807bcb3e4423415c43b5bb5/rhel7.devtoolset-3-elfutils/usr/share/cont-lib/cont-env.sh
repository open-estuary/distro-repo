. /usr/share/cont-lib/cont-lib.sh

cont_debug "changing environment variables"

cont_source_hooks env common

